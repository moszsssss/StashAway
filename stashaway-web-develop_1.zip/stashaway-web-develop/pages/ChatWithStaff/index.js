import React, { useState, useEffect } from "react";
import Member from "../../components/Member";
import Owner from "../../components/Owner";
import styled from "styled-components";

export default function index() {
  const [profile, setProfile] = useState({});
  const [statusUser, setStatusUser] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const liffId = `${process.env.NEXT_PUBLIC_LIFF_ID}`;

  useEffect(() => {
    const callLiff = async () => {
      const liff = (await import("@line/liff")).default;
      try {
        await liff.init({ liffId });
      } catch (error) {
        console.error("liff init error", error.message);
      }
      if (!liff.isLoggedIn()) {
        liff.login();
      } else {
        liff.getProfile().then((profile) => {
          setProfile(profile);
          console.log(profile);
        });
      }
    };
    callLiff();
  }, []);

  useEffect(() => {
    const findUser = async () => {
      try {
        const response = await fetch(`/api/profile/getProfile`, {
          method: "POST",
          body: JSON.stringify({
            user_line_id: profile.userId,
          }),
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (response?.status === 200) {
          setStatusUser("member");
          setIsLoading(false);
        } else {
          setStatusUser("Owner");
          setIsLoading(false);
        }
      } catch (error) {
        console.error(erroe);
      }
    };
    findUser();
  }, [profile.userId]);

  return (
    <>
      {isLoading ? (
        <></>
      ) : (
        <Container>
          {statusUser === "member" ? (
            <Member userId={profile.userId} />
          ) : (
            <Owner userId={profile.userId} lineName={profile.displayName} />
          )}
        </Container>
      )}
    </>
  );
}

const Container = styled.div`
  height: 100vh;
`;
