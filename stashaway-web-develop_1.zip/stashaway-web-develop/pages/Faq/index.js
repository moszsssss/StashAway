import React from "react";
import styled from "styled-components";
import FAQForm from "../../components/FAQForm";
import Headers from "../../components/Header";
import Image from "next/image";

export default function index() {
  return (
    <Container>
      <FAQForm />
    </Container>
  );
}

const Container = styled.div`
  height: 100vh;
`;
