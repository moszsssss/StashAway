import { useEffect, useState } from "react";
import "../styles/globals.css";

const liffId = `${process.env.NEXT_PUBLIC_LIFF_ID}`;

function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />;
}

export default MyApp;
