import { isEmpty } from "lodash";
import {
  HTTP_STATUS_NOT_FOUND,
  HTTP_STATUS_BAD_REQUEST,
  HTTP_STATUS_OK,
  HTTP_STATUS_METHOD_NOT_ALLOWED,
} from "../../../utils/httpStatusCode";
import { db } from "../../../lib/db";

export default async function handler(req, res) {
  const { id } = req.query;
  console.log(id);
  try {
    const dataUser = await db.profile_register.findFirst({
      where: { user_line_id: id },
    });
    let result = [];
    if (!isEmpty(dataUser)) {
      console.log("------" + JSON.stringify(dataUser, null, 2));

      return res.status(HTTP_STATUS_OK).json({
        result: dataUser,
        message: "200",
      });
    }
  } catch (error) {
    res
      .status(HTTP_STATUS_BAD_REQUEST)
      .json({ result: {}, message: error?.message });
  }
}
