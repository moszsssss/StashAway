import { isEmpty } from "lodash";
import {
  HTTP_STATUS_NOT_FOUND,
  HTTP_STATUS_BAD_REQUEST,
  HTTP_STATUS_OK,
  HTTP_STATUS_METHOD_NOT_ALLOWED,
} from "../../../utils/httpStatusCode";
import { db } from "../../../lib/db";

export default async function handler(req, res) {
  if (req.method === "GET") {
    return await findLineIdUser(req, res);
  }
  return res
    .status(HTTP_STATUS_METHOD_NOT_ALLOWED)
    .json({ message: "Request HTTP Method Incorrect." });
}
const findLineIdUser = async (req, res) => {
  try {
    const { user_line_id } = req.query;
    const user = await db.profile_register.findFirst({
      where: { user_line_id: user_line_id },
    });
    if (isEmpty(user)) {
      return res.status(HTTP_STATUS_OK).json({
        status: true,
        message: "Send find successfully",
      });
    } else {
      return res.status(HTTP_STATUS_NOT_FOUND).json({
        status: false,
        message: "Not Found lineID",
      });
    }
  } catch (error) {
    console.error(HTTP_STATUS_BAD_REQUEST);
  }
};
