import { isEmpty } from "lodash";
import {
  HTTP_STATUS_NOT_FOUND,
  HTTP_STATUS_BAD_REQUEST,
  HTTP_STATUS_OK,
  HTTP_STATUS_METHOD_NOT_ALLOWED,
} from "../../../utils/httpStatusCode";
import { db } from "../../../lib/db";

export default async function handler(req, res) {
  if (req.method === "POST") {
    return await updateStatusUser(req, res);
  }
  return res
    .status(HTTP_STATUS_METHOD_NOT_ALLOWED)
    .json({ message: "Request HTTP Method Incorrect." });
}

const updateStatusUser = async (req, res) => {
  try {
    const { user_line_id } = req.body;
    const updateUser = await db.profile_register.update({
      where: {
        user_line_id: user_line_id,
      },
      data: {
        status: "open",
      },
    });
    return res.status(200).json({ xx: "xx" });
  } catch (error) {
    console.error(error);
  }
};
