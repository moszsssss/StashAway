import { isEmpty } from "lodash";
import {
  HTTP_STATUS_NOT_FOUND,
  HTTP_STATUS_BAD_REQUEST,
  HTTP_STATUS_OK,
  HTTP_STATUS_METHOD_NOT_ALLOWED,
} from "../../../utils/httpStatusCode";
import { db } from "../../../lib/db";

export default async function handler(req, res) {
  if (req.method === "POST") {
    try {
      const { user_line_id } = req.body;
      const user = await db.profile_register.findFirst({
        where: { user_line_id: user_line_id },
      });
      if (!isEmpty(user)) {
        return res.status(200).json({ message: 200 });
      } else {
        return res.status(404).json({ message: 404 });
      }
    } catch (error) {
      console.error(HTTP_STATUS_BAD_REQUEST);
    }
  } else {
    return res
      .status(HTTP_STATUS_METHOD_NOT_ALLOWED)
      .json({ message: "Request HTTP Method Incorrect." });
  }
}
const getLineIdUser = async (req, res) => {};
