import { isEmpty } from "lodash";
import {
  HTTP_STATUS_NOT_FOUND,
  HTTP_STATUS_BAD_REQUEST,
  HTTP_STATUS_OK,
  HTTP_STATUS_METHOD_NOT_ALLOWED,
} from "../../../utils/httpStatusCode";
import { db } from "../../../lib/db";

export default async function handler(req, res) {
  if (req.method === "POST") {
    return await createUser(req, res);
  }
  return res
    .status(HTTP_STATUS_METHOD_NOT_ALLOWED)
    .json({ message: "Request HTTP Method Incorrect." });
}

const createUser = async (req, res) => {
  try {
    let user = null;
    const data = getUser(req.body);
    user = await db.profile_register.create({
      data,
    });
    return res.status(201).json(user);
  } catch (error) {
    console.log("error");
    console.error(error);
  }
};
const getUser = ({
  user_name,
  user_line_id,
  user_line_name,
  phone_number,
  user_email,
}) => {
  return {
    user_name,
    user_line_id,
    user_line_name,
    phone_number,
    user_email,
  };
};
