const request = require("request");
import CardMessage from "./CardMessage.json";
import { PrismaClient, Prisma } from "@prisma/client";
import { isEmpty } from "lodash";
export default async function handler(req, res) {
  res.status(200).json({ message: "OK" });
  console.log("req", req.body);
  const prisma = new PrismaClient();
  if (!isEmpty(req.body.destination)) {
    const user = await prisma.profile_register.findUnique({
      where: {
        user_line_id: req?.body?.events[0]?.source?.userId,
      },
    });
    if (isEmpty(user)) {
      const pushMessage = {
        method: "POST",
        url: `https://api.line.me/v2/bot/message/push`,
        headers: {
          Authorization: `Bearer ${process.env.CHANNEL_LINE_ACCESS_TOKEN}`,
          "Content-Type": "application/json",
        },
        json: true,
        body: {
          messages: [
            {
              type: "text",
              text: "หากท่านต้องการสอบถามข้อมูล กรุณากดที่เมนู Contact Us",
            },
          ],
          to: req?.body?.events[0]?.source?.userId,
        },
      };
      request(pushMessage, async (error, response, userData) => {
        console.error({ error, userData });
      });
    } else {
      if (user?.status === "open") {
        const options = {
          headers: {
            ...req.headers,
            host: `${process.env.NEXT_PUBLIC_ZENDESK_HOST}`,
          },
          method: "POST",
          url: `${process.env.NEXT_PUBLIC_ZENDESK_URL}`,
          json: true,
          body: req.body,
        };

        setTimeout(() => {
          request(options, (error, response, data) => {
            console.log(response?.statusCode);
          });
        }, 10);
      } else {
        const pushMessage = {
          method: "POST",
          url: `https://api.line.me/v2/bot/message/push`,
          headers: {
            Authorization: `Bearer ${process.env.CHANNEL_LINE_ACCESS_TOKEN}`,
            "Content-Type": "application/json",
          },
          json: true,
          body: {
            messages: [
              {
                type: "text",
                text: "หากท่านต้องการสอบถามข้อมูล กรุณากดที่เมนู Contact Us",
              },
            ],
            to: req?.body?.events[0]?.source?.userId,
          },
        };
        request(pushMessage, async (error, response, userData) => {
          console.error({ error, userData });
        });
      }
    }
  } else {
    if (req?.body?.events[0]["message"]["type"] === "zendesk") {
      const found = req.body.comment.match(
        /\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}/
      );
      const updateUser = await prisma.profile_register.update({
        where: {
          phone_number: found[0],
        },
        data: {
          status: "solved",
        },
      });
      const user = await prisma.profile_register.findUnique({
        where: {
          phone_number: found[0],
        },
      });
      const pushMessage = {
        method: "POST",
        url: `https://api.line.me/v2/bot/message/push`,
        headers: {
          Authorization: `Bearer ${process.env.CHANNEL_LINE_ACCESS_TOKEN}`,
          "Content-Type": "application/json",
        },
        json: true,
        body: {
          messages: [
            {
              type: "text",
              text: "ขอบคุณสำหรับการติดต่อเจ้าหน้าที่ หากท่านต้องการสอบถามเพิ่มเติมกรุณากดปุ่ม Contact Us และกรอกข้อมูลปัญหา เพื่อแจ้งให้เจ้าหน้าติดต่อกลับค่ะ",
            },
          ],
          to: user.user_line_id,
        },
      };
      request(pushMessage, async (error, response, userData) => {
        console.error({ error, userData });
      });
    }
  }

  if (req.body?.events[0]?.message.text === "ผลิตภัณฑ์การลงทุน") {
    const uuid = req?.body?.events[0]?.source?.userId;

    const pushMessage = {
      method: "POST",
      url: `https://api.line.me/v2/bot/message/push`,
      headers: {
        Authorization: `Bearer ${process.env.CHANNEL_LINE_ACCESS_TOKEN}`,
        "Content-Type": "application/json",
      },
      json: true,
      body: {
        messages: [CardMessage],
        to: uuid,
      },
    };
    request(pushMessage, async (error, response, userData) => {
      console.error({ error, userData });
    });
  }
}
