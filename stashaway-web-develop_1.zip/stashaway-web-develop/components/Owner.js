import React, { useEffect, useState } from "react";
import styled from "styled-components";
import Image from "next/image";
import StashAway from "../images/Logo-StashAway.png";
import { Input, Button, Label } from "reactstrap";
import { useForm } from "react-hook-form";
import ModalTermCondition from "../components/ModalTermCondition";
import isEmpty from "lodash/isEmpty";
import Check from "../images/check.svg";
import Uncheck from "../images/uncheck.svg";

export default function Owner({ userId, lineName }) {
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm();

  const [isAccept, setIsAccept] = useState(false);
  const [isOpenModal, setIsOpenModal] = useState(false);

  const [isDisabled, setIsDisabled] = useState(true);
  const [isErrorMessage, setIsErrorMessages] = useState([]);

  const name = watch("name", "");
  const email = watch("email", "");
  const phoneNumber = watch("phoneNumber", "");

  useEffect(() => {
    if (
      isEmpty(isErrorMessage) &&
      !isEmpty(name) &&
      !isEmpty(email) &&
      !isEmpty(phoneNumber) &&
      isAccept === true
    ) {
      setIsDisabled(false);
    } else {
      setIsDisabled(true);
    }
  }, [name, email, phoneNumber, isAccept, isErrorMessage]);

  useEffect(() => {
    let mailValidate = email.trim();
    const mail_format = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{1,4})+$/;
    let errorsList = isErrorMessage;

    if (!isEmpty(mailValidate) && !mailValidate?.match(mail_format)) {
      errorsList = {
        ...errorsList,
        email: "กรุณากรอกอีเมลของท่านให้ถูกต้อง",
      };
    } else {
      delete errorsList.email;
    }

    setValue("email", mailValidate);
    setIsErrorMessages(errorsList);
  }, [email]);

  useEffect(() => {
    const special_characters = /[0-9!@#\$%\^\&*\)\(+=._-]+$/g;
    let errorsList = isErrorMessage;
    if (!isEmpty(name) && name?.match(special_characters)) {
      errorsList = {
        ...errorsList,
        name: "กรุณากรอกชื่อ-นามสกุลของท่านให้ถูกต้อง",
      };
    } else {
      delete errorsList.name;
    }
    setIsErrorMessages(errorsList);
  }, [name]);

  useEffect(() => {
    if (phoneNumber) {
      const handleEnterPhoneNumber = (phoneNumber) => {
        let newNumber,
          input = phoneNumber.replace(/\D/g, "");
        let errorsList = isErrorMessage;

        newNumber = input;
        if (input.length > 3) {
          const firstThreeCharPhoneNumber = input.substring(0, 3);
          newNumber = `${firstThreeCharPhoneNumber}-`;
          if (input.length === 4 || input.length === 5 || input.length === 6) {
            newNumber += input.substr(3);
          } else if (input.length > 6) {
            newNumber += `${input.substring(3, 6)}-`;
          }
          if (input.length > 6) {
            newNumber += input.substring(6);
          }
        }
        if (newNumber.length < 12) {
          errorsList = {
            ...errorsList,
            phone: "กรุณากรอกเบอร์โทรให้ถูกต้อง",
          };
        } else {
          delete errorsList.phone;
        }
        setIsErrorMessages(errorsList);

        setValue(
          "phoneNumber",
          newNumber.length > 12 ? newNumber.substring(0, 12) : newNumber
        );
      };

      handleEnterPhoneNumber(phoneNumber);
    }
  }, [phoneNumber]);

  const closeModal = () => {
    setIsOpenModal(false);
  };

  const handleModal = () => {
    setIsOpenModal(!isOpenModal);
    setIsAccept(true);
  };

  const onSubmit = async (data) => {
    if (isEmpty(isErrorMessage)) {
      if (name != "" && email != "" && phoneNumber != "" && isAccept === true) {
        setIsDisabled(true);
        await SendMessages();
      }
    }
  };

  const SendMessages = async () => {
    const liff = (await import("@line/liff")).default;
    await liff
      .init({ liffId: `${process.env.NEXT_PUBLIC_LIFF_ID}` })
      .then(() => {
        liff
          .sendMessages([
            {
              type: "text",
              text: `ติดต่อเจ้าหน้าที่\n\nชื่อ:${" " + name}\nอีเมล:${
                " " + email
              }\nเบอร์โทร:${" " + phoneNumber}`,
            },
          ])
          .then(() => {
            handleRegister();
          })
          .catch((err) => {
            console.log("error", err);
          });
      });
  };

  const handleClosePopup = async () => {
    const liff = (await import("@line/liff")).default;
    liff.closeWindow();
  };

  const handleRegister = async () => {
    const response = await fetch(`/api/register`, {
      method: "POST",
      body: JSON.stringify({
        user_name: name,
        user_line_id: userId,
        user_line_name: lineName,
        phone_number: phoneNumber,
        user_email: email,
      }),
      headers: {
        "Content-Type": "application/json",
      },
    });
    handleClosePopup();
    return response;
  };
  const handleChecking = () => {
    setIsAccept(!isAccept);
  };

  return (
    <Container>
      <BodyContent>
        <ImageDiv>
          <Image src={StashAway} alt="StashAway" width="95px" height="24px" />
        </ImageDiv>
        <HeaderDiv>
          <HeaderSpan>ติดต่อทีมงานดูแลลูกค้า</HeaderSpan>
          <TitleSpan>กรุณาใส่ข้อมูล</TitleSpan>
        </HeaderDiv>
        <FormInput>
          <InputDiv>
            <TitleDiv>
              <Title>ชื่อ</Title>
              <SpanStar>*</SpanStar>
            </TitleDiv>
            <Inputs
              type="text"
              id="exampleInput"
              placeholder="ชื่อ-สกุล"
              {...register("name")}
            />
          </InputDiv>
          <InputDiv>
            <TitleDiv>
              <Title>อีเมล</Title>
              <SpanStar>*</SpanStar>
            </TitleDiv>
            <Inputs
              type="email"
              id="exampleInput"
              placeholder="name@email.com"
              {...register("email")}
            />
          </InputDiv>
          <InputDiv>
            <TitleDiv>
              <Title>เบอร์โทรศัพท์มือถือ</Title>
              <SpanStar>*</SpanStar>
            </TitleDiv>
            <Inputs
              type="string"
              name="phoneNumber"
              maxLength={12}
              placeholder="088-888-8888"
              {...register("phoneNumber")}
            />
          </InputDiv>
        </FormInput>
        <CheckBox>
          <LabelChecked onClick={handleChecking}>
            {isAccept ? (
              <IconCheck src={Check} alt="check" />
            ) : (
              <IconCheck src={Uncheck} alt="uncheck" />
            )}
            <TitleCheckbox>ฉันยอมรับ</TitleCheckbox>
          </LabelChecked>
          <SpanLinkText onClick={handleModal}>
            นโยบายความเป็นส่วนตัว
          </SpanLinkText>
        </CheckBox>
      </BodyContent>
      <Space />
      <ButtonSend
        onClick={handleSubmit(onSubmit)}
        active={isDisabled}
        style={{ opacity: isDisabled ? "0.5" : "1" }}
      >
        <TextButton>เริ่มติดต่อ</TextButton>
      </ButtonSend>

      {isOpenModal && (
        <ModalTermCondition isOpen={isOpenModal} onRequestClose={closeModal} />
      )}
    </Container>
  );
}

const Space = styled.div`
  height: 7vh;
`;
const Container = styled.div`
  height: 100%;
`;

const BodyContent = styled.div`
  padding: 0 24px;
`;

const IconCheck = styled(Image)`
  border-radius: 5px;
  width: 26px;
  height: 26px;
`;

const ButtonSend = styled(Button)`
  background-color: #4d91dd;
  color: white;
  text-align: center;
  align-items: center;
  height: 56px;
  width: 88%;
  border-radius: 8px;
  border-width: 0;
  margin: 0 20px 25px 20px;
`;

const HeaderDiv = styled.div`
  display: flex;
  flex-direction: column;
`;

const HeaderSpan = styled.span`
  font-weight: bold;
  font-size: 24px;
  line-height: 135%;
  color: #072340;
`;

const TitleSpan = styled.span`
  font-weight: 400;
  font-size: 16px;
  line-height: 135%;
  color: #072340;
  padding: 1% 0;
`;

const ImageDiv = styled.div`
  padding: 5px 0 18px 0;
`;

const FormInput = styled.div`
  margin-top: 5vh;
`;

const TextButton = styled.div`
  font-size: 16px;
  font-weight: 500;
`;

const CheckBox = styled.div`
  display: flex;
  flex-direction: row;
  margin-top: 15px;
  align-items: center;
`;

const Inputs = styled.input`
  width: 100%;
  height: 56px;
  padding: 8px;
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 135%;
  color: #0d0a1d;
  background: #f1f1f1;
  border-radius: 5px;
  border-width: 0px;
`;

const InputDiv = styled.div`
  padding: 5px 0;
`;

const SpanStar = styled.span`
  font-weight: 400;
  font-size: 16px;
  line-height: 135%;
  color: #d33b36;
  padding-left: 3px;
`;

const Title = styled.span`
  font-weight: 400;
  font-size: 16px;
  line-height: 135%;
  color: #666666;
`;

const TitleDiv = styled.div`
  padding: 8px 0;
`;

const LabelChecked = styled(Label)`
  display: flex;
  flex-direction: row;
  align-items: center;
`;

const SpanLinkText = styled.div`
  color: #4d91dd;
  font-weight: bold;
  font-size: 16px;
  line-height: 135%;
  padding-left: 5px;
`;
const TitleCheckbox = styled.span`
  color: #393e47;
  font-weight: 400;
  font-size: 16px;
  line-height: 135%;
  display: flex;
  flex-direction: row;
  padding-left: 10px;
`;
