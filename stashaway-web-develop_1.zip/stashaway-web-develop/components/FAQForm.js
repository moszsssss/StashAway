import React from "react";
import styled from "styled-components";
import map from "lodash/map";
import Link from "next/link";
import Image from "next/image";
import StashAway from "../images/Logo-StashAway.png";

export default function FAQForm() {
  const dataContents = [
    {
      title: "ระบบจะแสดงเงินลงทุนที่ฝากเข้าบัญชี StashAway เมื่อไหร่",
      linkOut: "https://www.stashaway.co.th/th-TH/help-center/4404952151705",
    },
    {
      title: "กำหนดขั้นต่ำสำหรับการฝากเงินลงทุนในแต่ละครั้งไหม",
      linkOut: "https://www.stashaway.co.th/th-TH/help-center/4404952356249",
    },
    {
      title: "ดูผลตอบแทนจากการลงทุนได้ที่ไหน",
      linkOut: "https://www.stashaway.co.th/th-TH/help-center/4404968377369",
    },
    {
      title: "ดูธุรกรรมของบัญชีได้ที่ไหน",
      linkOut: "https://www.stashaway.co.th/th-TH/help-center/4404886313497",
    },
    {
      title: "การทำ Re-optimisation คืออะไร",
      linkOut: "https://www.stashaway.co.th/th-TH/help-center/4405256637849",
    },
    {
      title: "คำถามที่พบบ่อยทั้งหมด",
      linkOut: "https://www.stashaway.co.th/th-TH/help-center",
    },
  ];
  return (
    <>
      <ImageDiv>
        <Image src={StashAway} alt="StashAway" width="95px" height="24px" />
      </ImageDiv>
      <Container>
        <Header>
          <HeaderText>คำถามที่พบบ่อยทั้งหมด</HeaderText>
          <HeaderFAQ>FAQ6665555</HeaderFAQ>
        </Header>
        {map(dataContents, (val, index) => {
          return (
            <Link key={index} href={val.linkOut}>
              <Contents>
                <TextContent>{val.title}</TextContent>
              </Contents>
            </Link>
          );
        })}
      </Container>
    </>
  );
}

const Container = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  flex: 1;
  padding: 0 24px;
  background-color: #fff;
`;

const HeaderFAQ = styled.span`
  font-weight: 600;
  font-size: 24px;
  line-height: 140%;
  color: #072340;
`;
const HeaderText = styled.span`
  font-weight: 400;
  font-size: 16px;
  line-height: 135%;
  color: #072340;
`;

const Header = styled.div`
  padding: 35px 0;
  display: flex;
  flex-direction: column;
`;

const Contents = styled.div`
  background-color: #e1f4f3;
  padding: 20px;
  border-radius: 6px;
  margin: 10px 0;
  width: 100%;
  min-height: 80px;
`;
const TextContent = styled.span`
  font-weight: 600;
  font-size: 14px;
  line-height: 140%;
  color: #484848;
`;

const ImageDiv = styled.div`
  padding: 20px 24px 0 24px;
  width: 100%;
  background-color: #f8f8f8;
`;
