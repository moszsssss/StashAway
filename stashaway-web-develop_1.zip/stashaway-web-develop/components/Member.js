import React, { useEffect, useState } from "react";
import styled from "styled-components";
import Image from "next/image";
import StashAway from "../images/Logo-StashAway.png";
import { Input, Button } from "reactstrap";
import { useForm } from "react-hook-form";

export default function Member({ userId }) {
  const { handleSubmit, watch, setValue } = useForm();

  const [status, setStatus] = useState(true);
  const [profile, setProfile] = useState({});

  const title = watch("title") || "";

  useEffect(() => {
    if (title != "" || title != "undefined") {
      setStatus(false);
    }
  }, [title]);

  useEffect(() => {
    const findUser = async () => {
      try {
        const sendUserId = await fetch(`/api/profile/${userId}`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const data = await sendUserId.json();
        setProfile(data.result);
      } catch (error) {
        console.error(error);
      }
    };
    findUser();
  }, [userId]);

  const SendMessages = async () => {
    const liff = (await import("@line/liff")).default;
    await liff
      .init({ liffId: `${process.env.NEXT_PUBLIC_LIFF_ID}` })
      .then(() => {
        liff
          .sendMessages([
            {
              type: "text",
              text: `ติดต่อเจ้าหน้าที่\n\nเรื่อง:${" " + title}\n\nชื่อ:${
                " " + profile?.user_name
              }\nอีเมล:${" " + profile?.user_email}\nเบอร์โทร:${
                " " + profile?.phone_number
              }`,
            },
          ])
          .then(async () => {
            try {
              const response = await fetch(`/api/profile/updateStatus`, {
                method: "POST",
                body: JSON.stringify({
                  user_line_id: userId,
                }),
                headers: {
                  "Content-Type": "application/json",
                },
              });
              if (response?.status === 200) {
                handleClosePopup();
              }
            } catch (error) {
              console.log("error");
            }
          })
          .catch((err) => {
            console.log("error", err);
          });
      });
  };

  const handleClosePopup = async () => {
    const liff = (await import("@line/liff")).default;
    liff.closeWindow();
  };

  const handleChange = (text) => {
    const textValue = text.replace(/\\n/g, "\n");
    setValue("title", textValue);
    setStatus(false);
  };

  const onSubmit = () => {
    if (status === false && title != "") {
      setStatus(true);
      SendMessages();
    }
  };

  return (
    <Container>
      <Contents>
        <ImageDiv>
          <Image src={StashAway} alt="StashAway" width="95px" height="24px" />
        </ImageDiv>
        <Header>ติดต่อทีมงานดูแลลูกค้า</Header>
        <Title>กรุณาใส่ข้อมูล</Title>
        <FormInput
          type="textarea"
          name="description"
          value={title}
          placeholder="สวัสดีค่ะ วันนี้ให้ทีมงานดูแลเรื่องอะไรดีค่ะ?"
          rows="5"
          maxLength={700}
          onChange={(e) => handleChange(e.target.value)}
        />
      </Contents>
      <ButtonStart
        onClick={handleSubmit(onSubmit)}
        active={status}
        style={{ opacity: status == true ? "0.5" : "1" }}
      >
        <TextButtom> เริ่มติดต่อ</TextButtom>
      </ButtonStart>
    </Container>
  );
}
const Container = styled.div`
  display: flex;
  flex-direction: column;
`;
const ImageDiv = styled.div`
  padding: 20px 24px 18px 0px;
  width: 100%;
`;
const Header = styled.span`
  font-weight: bold;
  font-size: 24px;
  line-height: 135%;
  color: #072340;
  letter-spacing: -1px;
`;
const Title = styled.span`
  font-weight: 400;
  font-size: 16px;
  line-height: 135%;
  color: #072340;
`;
const Contents = styled.div`
  display: flex;
  flex-direction: column;
  padding: 0px 24px;
  height: 80vh;
`;

const FormInput = styled(Input)`
  margin-top: 50px;
  padding-top: 20px;
  font-weight: 400;
  font-size: 16px;
  line-height: 135%;
  color: #0d0a1d;
  background: #f1f1f1;
  border-radius: 5px;
  border-width: 0px;
  padding: 13px;
`;

const ButtonStart = styled(Button)`
  background-color: #4d91dd;
  align-self: center;
  text-align: center;
  color: white;
  height: 56px;
  width: 88%;
  border-radius: 8px;
  border-width: 0;
`;

const TextButtom = styled.span`
  font-weight: 700;
  font-size: 16px;
  line-height: 140%;
  text-align: center;

  letter-spacing: 0.25px;
  color: #ffffff;
`;
