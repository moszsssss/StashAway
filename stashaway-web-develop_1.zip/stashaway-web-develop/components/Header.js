import React from "react";
import styled from "styled-components";
export default function Header({ name, urlPath }) {
  return (
    <Container>
      <IconLeft>
        <Icon>icon1</Icon>
        <Icon>icon2</Icon>
      </IconLeft>

      <TextHeader>
        <div>{name}</div>
        <div>{urlPath}</div>
      </TextHeader>
      <IconRight>
        <Icon>icon 3</Icon>
      </IconRight>
    </Container>
  );
}

const Container = styled.div`
  background-color: #f2f9;
  display: flex;
  flex-direction: row;
  flex: 1;
  width: 100%;
`;
const Icon = styled.div`
  padding: 10px;
`;
const IconLeft = styled.div`
  display: flex;
  flex-direction: row;
  background-color: aqua;
  align-items: center;
`;
const IconRight = styled.div`
  align-self: center;
`;
const TextHeader = styled.div`
  text-align: center;
  background-color: aquamarine;
  padding: 5px;
  flex: 1;
`;
