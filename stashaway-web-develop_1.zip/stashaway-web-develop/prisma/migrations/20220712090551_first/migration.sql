-- CreateTable
CREATE TABLE "profile_register" (
    "id" SERIAL NOT NULL,
    "user_name" TEXT NOT NULL,
    "user_line_id" TEXT NOT NULL,
    "user_line_name" TEXT NOT NULL,
    "status" TEXT DEFAULT 'open',
    "phone_number" TEXT NOT NULL,
    "user_email" TEXT NOT NULL,
    "create_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "profile_register_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "profile_register_user_name_key" ON "profile_register"("user_name");

-- CreateIndex
CREATE UNIQUE INDEX "profile_register_user_line_id_key" ON "profile_register"("user_line_id");

-- CreateIndex
CREATE UNIQUE INDEX "profile_register_user_line_name_key" ON "profile_register"("user_line_name");

-- CreateIndex
CREATE UNIQUE INDEX "profile_register_phone_number_key" ON "profile_register"("phone_number");

-- CreateIndex
CREATE UNIQUE INDEX "profile_register_user_email_key" ON "profile_register"("user_email");
