-- AlterTable
ALTER TABLE "profile_register" ALTER COLUMN "user_name" DROP NOT NULL,
ALTER COLUMN "user_line_id" DROP NOT NULL,
ALTER COLUMN "user_line_name" DROP NOT NULL,
ALTER COLUMN "phone_number" DROP NOT NULL,
ALTER COLUMN "user_email" DROP NOT NULL;
